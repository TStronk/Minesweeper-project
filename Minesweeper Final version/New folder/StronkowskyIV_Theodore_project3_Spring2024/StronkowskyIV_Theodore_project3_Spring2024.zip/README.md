1 Name: Theodore John Stronkowsky IV
2 Section: COP3503C(23372)
3 UFL email: Tstronkowsky@ufl.edu
4 System: Windows
5 Compiler: g++
6 SFML version: SFML - 2.5.1
7 IDE: Visual Studios Code
8 Other notes: In order to run The two windows properly I needed two folders one for the welcome window, respectively the "files" folder, and another for the Minesweeper window, respectively the "src" folder.
		Please incorporate the "images" folder, the "board_config.cfg" file , the "font.tff" file, and the "leaderboard.txt" file in the "files" folder to properly run Minesweeper.
